const productDemoImg1 = "assets/images/woman.png";
const productDemoImg2 = "assets/images/kids.png";
const productDemoImg3 = "assets/images/man.png";
const productDemoImg4 = "assets/images/woman.png";
const productDemoImg5 = "assets/images/man.png";
const productDemoImg6 = "assets/images/man.png";
