import 'package:ecommerce_mobile_ui/core/theming/colors.dart';
import 'package:ecommerce_mobile_ui/entry_point.dart';
import 'package:ecommerce_mobile_ui/features/pages/cart_screen.dart';
import 'package:ecommerce_mobile_ui/features/pages/fav_screen.dart';
import 'package:ecommerce_mobile_ui/features/pages/home_screen.dart';
import 'package:ecommerce_mobile_ui/features/pages/offers_screen.dart';
import 'package:ecommerce_mobile_ui/features/pages/profile_screen.dart';
import 'package:flutter/material.dart';
import 'package:hidden_drawer_menu/hidden_drawer_menu.dart';

import '../../core/theming/styles.dart';

class HiddenDrawar extends StatefulWidget {
  const HiddenDrawar({super.key});

  @override
  State<HiddenDrawar> createState() => _HiddenDrawarState();
}

class _HiddenDrawarState extends State<HiddenDrawar> {
  List<ScreenHiddenDrawer> _pages = [];

  @override
  void initState() {
    super.initState();
    _pages = [
      ScreenHiddenDrawer(
          ItemHiddenMenu(
              name: 'Fashion Feed',
              baseStyle: TextStyles.font16WhiteSemiBold,
              selectedStyle: TextStyles.font26WhiteBold),
          EntryPoint()),
      ScreenHiddenDrawer(
          ItemHiddenMenu(
              name: 'Offers',
              baseStyle: TextStyles.font16WhiteSemiBold,
              selectedStyle: TextStyles.font26WhiteBold),
          OffersScreen()),
      ScreenHiddenDrawer(
          ItemHiddenMenu(
              name: 'Bags',
              baseStyle: TextStyles.font16WhiteSemiBold,
              selectedStyle: TextStyles.font26WhiteBold),
          CartScreen()),
      ScreenHiddenDrawer(
          ItemHiddenMenu(
              name: 'Wish',
              baseStyle: TextStyles.font16WhiteSemiBold,
              selectedStyle: TextStyles.font26WhiteBold),
          FavScreen()),
      ScreenHiddenDrawer(
          ItemHiddenMenu(
              name: 'Profile',
              baseStyle: TextStyles.font16WhiteSemiBold,
              selectedStyle: TextStyles.font26WhiteBold),
          ProfileScreen()),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return HiddenDrawerMenu(
      screens: _pages,
      backgroundColorMenu: ColorsManager.mainRed,
      initPositionSelected: 0,
      elevationAppBar: 0,
      backgroundColorAppBar: Colors.white,
    );
  }
}
