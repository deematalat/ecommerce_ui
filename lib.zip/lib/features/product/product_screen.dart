import 'package:ecommerce_mobile_ui/core/helpers/extensions.dart';
import 'package:ecommerce_mobile_ui/features/product/widgets/product_card.dart';
import 'package:ecommerce_mobile_ui/features/product/widgets/sort_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '../../core/routing/routes.dart';
import '../../core/theming/colors.dart';
import '../../core/theming/styles.dart';
import 'model/product_model.dart';

class ProductScreen extends StatefulWidget {
  const ProductScreen({super.key});

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  VoidCallback? _showBottomSheetCallback;
  late List<ProductModel> sortList;
  List<ProductModel> originalProducts = demoPopularProducts;  // to retain the original list

  @override
  void initState() {
    super.initState();
    sortList = originalProducts;
    _showBottomSheetCallback = _showPersistentBottomSheet;
  }

  // Sorting method
  void sortProducts(String sortBy) {
    setState(() {
      if (sortBy == "Popularity") {
        sortList = demoBestSellersProducts; // You can adjust the popularity logic
      } else if (sortBy == "New") {
        // Add logic for new products sorting (if you have a 'date' field or something else)
      } else if (sortBy == "Discount") {
        sortList.sort((a, b) => (b.dicountpercent ?? 0).compareTo(a.dicountpercent ?? 0));
      } else if (sortBy == "price:High-Low") {
        sortList.sort((a, b) => b.price.compareTo(a.price));
      } else if (sortBy == "Price:Low-High") {
        sortList.sort((a, b) => a.price.compareTo(b.price));
      }
    });
  }

  void _showPersistentBottomSheet() {
    setState(() {
      _showBottomSheetCallback = null;
    });

    showBottomSheet(
      elevation: 25,
      context: context,
      builder: (BuildContext context) {
        return BottomSheetContent(
          onSortSelected: sortProducts,  // Pass the sorting method
        );
      },
    ).closed.whenComplete(() {
      if (mounted) {
        setState(() {
          _showBottomSheetCallback = _showPersistentBottomSheet;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.moreLightGray,
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text("Woman top"),
        actions: [
          IconButton(
            onPressed: () {
              context.pushNamed(Routes.searchScreen);
            },
            icon: SvgPicture.asset(
              "assets/icons/Search.svg",
              height: 24,
              colorFilter: ColorFilter.mode(ColorsManager.gray, BlendMode.srcIn),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            color: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextButton(
                  onPressed: _showBottomSheetCallback,
                  child: Text(
                    "Sort By",
                    style: TextStyles.font18blackBold,
                  ),
                ),
                TextButton(
                    onPressed: () {
                      context.pushNamed(Routes.twoPaneScreen);
                    },
                    child: Text("Refine", style: TextStyles.font18blackBold))
              ],
            ),
          ),
          Expanded(
            child: Builder(
              builder: (context) {
                return GridView.builder(
                  scrollDirection: Axis.vertical,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 8.0,
                    crossAxisSpacing: 8.0,
                  ),
                  padding: EdgeInsets.all(8.0),
                  itemCount: sortList.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        context.pushNamed(Routes.productDetailsScreen, arguments: {"index": index});
                      },
                      child: Hero(
                        tag: index,
                        child: ProductCard(
                          image: sortList[index].image,
                          brandName: sortList[index].brandName,
                          title: sortList[index].title,
                          price: sortList[index].price,
                          priceAfetDiscount: sortList[index].priceAfetDiscount,
                          dicountpercent: sortList[index].dicountpercent,
                          press: () {},
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

