import 'package:ecommerce_mobile_ui/core/helpers/extensions.dart';
import 'package:ecommerce_mobile_ui/core/helpers/spacing.dart';
import 'package:ecommerce_mobile_ui/core/theming/styles.dart';
import 'package:ecommerce_mobile_ui/core/widgets/app_text_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../core/helpers/constants.dart';
import '../../core/theming/colors.dart';
import '../../core/widgets/show_snack_bar.dart';
import 'model/product_model.dart';

class ProductDetailScreen extends StatefulWidget {

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  @override
  Widget build(BuildContext context) {
    final arguments = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>? ??{};


    final _index = arguments['index'] ?? 0;
    print(_index);
    final productItem=demoPopularProducts[_index];
     late String _selectedSize='';
     late  Color _selectedColor;
    return Hero(
      tag: _index,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          title: const Text('MISS CHASE'),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 20),
              child: Badge(
                label: Text(cartProductsList.length.toString()),
                child: Icon(Icons.shopping_bag),
              ),
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.asset(productItem.image,
              width:double.infinity,
              height:500.h,
              ),
              verticalSpace(30),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(productItem.title),
                    verticalSpace(10),
                    Row(
                      children: [
                        Text(productItem.price.toString()),
                      horizontalSpace(8),
                        Text(productItem.priceAfetDiscount.toString(),
                            style: TextStyle(decoration: TextDecoration.lineThrough)),
                        horizontalSpace(8),
                        if (productItem.dicountpercent != null)
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 8.h),
                            height: 25.h,
                            decoration: const BoxDecoration(
                              color: ColorsManager.green,
                              borderRadius:
                              BorderRadius.all(Radius.circular(25)),
                            ),
                            child: Text(
                              "${productItem.dicountpercent}% off",
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                      ],
                    ),
                    verticalSpace(10),
                    Wrap(
                      spacing: 8,
                      children:['S', 'M', 'L', 'XL'].map((size) =>
                          ChoiceChip(
                            label: Text(size),
                            selected: false,
                            onSelected: (bool selected) {
                              selected==true? _selectedSize=size:null;
                            },
                          ),
                      ).toList(),
                    ),
                    verticalSpace(10),
                    // Color Selection
                    Text('SELECT COLOUR'),
                    verticalSpace(10),
                    Wrap(
                      spacing: 8,
                      children:[
                        Colors.blue,
                        Colors.green,
                        Colors.red,
                        Colors.yellow,
                      ].map((color) {
                        _selectedColor=color;
                       return GestureDetector(
                         onTap:(){
                         },
                         child: CircleAvatar(
                           backgroundColor: _selectedColor==color?ColorsManager.moreLightGray:Colors.white,
                           radius: 17,
                           child: CircleAvatar(
                                backgroundColor: color,
                                radius: 15,
                              ),
                         ),
                       );
                      }
                      ).toList(),
                    ),
                  ],
                ),
              ),
              verticalSpace(30),
              // Add to Bag Button
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: AppTextButton(
                  onPressed: () {
                    // Add to cart using Provider
                    if(_selectedSize!=''){
                    cartProductsList.add(ProductModel(
                      title:productItem.title,
                      price: productItem.priceAfetDiscount!,
                      priceAfetDiscount: productItem.price,
                      description: 'Keep your look lively as you wear this top',
                      image: productItem.image,
                      dicountpercent: productItem.dicountpercent, brandName: 'dior',
                      selectedColor:_selectedColor,
                      selectedSize: _selectedSize
                    ));
                    setState(() {
                      context.pop();
                    });}
                    else{
                      //todo:snackbar
                    }
                  },
                buttonText: 'ADD TO BAG', textStyle:TextStyles.font26WhiteBold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}