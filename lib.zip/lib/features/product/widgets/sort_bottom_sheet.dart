import 'package:flutter/material.dart';

class BottomSheetContent extends StatelessWidget {
  final List<String> sortByList = [
    "Popularity",
    "New",
    "Discount",
    "price:High-Law",
    "Price:Law-High",
  ];
  final Function(String) onSortSelected;

    BottomSheetContent({super.key, required this.onSortSelected});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 350,
      child: Column(
        children: [
          SizedBox(
            height: 70,
            child: Center(
              child: Text(
                "SORT BY",
                textAlign: TextAlign.center,
              ),
            ),
          ),
          const Divider(thickness: 1),
          Expanded(
            child: ListView.builder(
              itemCount: sortByList.length,
              itemBuilder: (context, index) {
                return ListTile(
               onTap: () {
                  onSortSelected(sortByList[index]);
                  Navigator.pop(context);  // Close bottom sheet
                },
                  title: Text(sortByList[index]),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
