import 'package:ecommerce_mobile_ui/core/helpers/extensions.dart';
import 'package:flutter/material.dart';
import '../../../core/helpers/constants.dart';
import '../../core/routing/routes.dart';
import 'model/product_model.dart'; // Assuming this is where the image URLs are defined.

class ProductSearchScreen extends StatefulWidget {
  @override
  _ProductSearchScreenState createState() => _ProductSearchScreenState();
}

class _ProductSearchScreenState extends State<ProductSearchScreen> {
  TextEditingController _searchController = TextEditingController();
  List<ProductModel> filteredProducts = demoPopularProducts; // Default list

  // Method to filter products based on search query
  void _filterProducts(String query) {
    List<ProductModel> tempList = [];
    if (query.isNotEmpty) {
      for (var product in demoPopularProducts) {
        if (product.title.toLowerCase().contains(query.toLowerCase()) ||
            product.brandName.toLowerCase().contains(query.toLowerCase())) {
          tempList.add(product);
        }
      }
    } else {
      tempList = demoPopularProducts; // Reset to all products if the search field is empty
    }

    setState(() {
      filteredProducts = tempList;
    });
  }

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      _filterProducts(_searchController.text);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Search Products'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search products...',
                border: OutlineInputBorder(),
                suffixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredProducts.length,
              itemBuilder: (context, index) {
                final product = filteredProducts[index];
                return ListTile(
                  leading: Image.network(product.image),
                  title: Text(product.title),
                  subtitle: Text(product.brandName),
                  trailing: Text('\$${product.price}'),
                  onTap: () {
                    //todo:when click nav to product details screen
                    context.pushNamed(Routes.productDetailsScreen,arguments:{'index':index});
                    // Navigate to product details screen or take any other action
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
